float dist;
unsigned char h;
unsigned int cntr4;
float distance;
int period;
unsigned char y;
int e;
float calc_dist(void);
void USART_init(void);
void ms_delay(unsigned int mscntr0);


void interrupt(void){
   cntr4++;
   if(cntr4==19500){// chech distance every 2.5sec
   cntr4=0;
  dist=calc_dist();
 }

   if(dist<35){  // If distance less than 35 stop
   PORTD=0x00;
   PORTB&=0x8F;
   y=0;
   while(y<7){
   y++;
        }
    PORTB|=0x70;

      INTCON=0xA0;}


    INTCON=0xA0;

   }


void main (){
 TRISB=0x02;      //RB0=trigger // RB1=echo
 PORTB=0x70;      // for lights
 T1CON= 0x00;     //TMR0=0
 OPTION_REG=0x88; //  TMR0 with no prescaler
 INTCON=0xA0;     // Global enable on, TMR0 interrupt on
 TRISC=0x00;
 TRISD=0X00;
 PORTD=0x00;
 RCREG=0x00;
 USART_init();

while(1){
 RCREG;

 if(RCREG==0x00){//move car right
  PORTD=0x10;
  ms_delay(400);
 }
 else if(RCREG==0x01){//move car left
  PORTD=0x40;
   ms_delay(400);
 }
  else if (RCREG==0x02){//stop car
   PORTD=0x00;
   ms_delay(400);
 }

  else if (RCREG==0x03){ //forward full-speed
  PORTD=0x50;
  ms_delay(400);
 }

  else if (RCREG==0x04){   //forward 75%-speed
   PORTD=0x50;
   ms_delay(300);
   PORTD=0x00;
   ms_delay(100);
 }
  else if (RCREG==0x05){  //backward full-speed
   PORTD=0xA0;
   ms_delay(400);
 }

  else if (RCREG==0x06){  //backward 75%-speed
   PORTD=0xA0;
   ms_delay(300);
   PORTD=0x00;
   ms_delay(100);
 }

  else {
  PORTD=0x00;
   ms_delay(400);
 }

}
}

float calc_dist(void) {
    h=0;
    period=0;
    distance=0;
    TMR1L=0;
    TMR1H=0;
    PORTB|=0x01;          // RB0 on send pulse (trigger)
    while(h<20){          //delay 10usec
     h++;
    }
    PORTB&=0xFE;          //RB0 stop pulse
    while(!(PORTB&0x02));
    T1CON=0x01;          // start TMR1 when pulse enter BR1 (ech)
    while(PORTB&0x02);
    T1CON=0x00;          // stop TMR1 when pulse end (low)
    period=((TMR1H<<8)|TMR1L);
    distance=period/117.65;    //TMR1(no of ticks)*4/Fosc (*340m/sec(speed of sound)/2
    return distance;

}




   void USART_init(void){
     SPBRG=103;    //1200BPS
     TXSTA=0X20;  // 8 -bit ,TX enable , Async, Low speed;
     RCSTA=0X90; //SP enable, continous RX
     TRISC=0x80;// RC7 input,RC^ output;
    // PORTC=0x00;
 }

   void ms_delay(unsigned int mscntr0){
       unsigned  int cntr=0;
       while(cntr<mscntr0){
       cntr++;}
 }


