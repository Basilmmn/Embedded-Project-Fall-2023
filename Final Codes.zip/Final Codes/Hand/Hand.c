void USART_init(void);
void USART_Tx(unsigned char mychar);
unsigned int ATD_read(int channel);
unsigned int xx;
unsigned int yy;
unsigned int zz;
unsigned int xvoltage;
unsigned int yvoltage;
unsigned int zvoltage;

void main() {
  TRISB=0X00;
  PORTB=0x01;
  USART_init();
  ADCON1 = 0xF0;//All channels are  Analog, 500 KHz, right justified


while(1){
  xx= ATD_read(0x49);
  yy= ATD_read(0x51);
  zz= ATD_read(0x59);

     xvoltage=(unsigned int)(((float) xx/10.23)*5);
     yvoltage=(unsigned int)(((float) yy/10.23)*5);
     zvoltage=(unsigned int)(((float) zz/10.23)*5);


          if(xvoltage>=130&&xvoltage <149){// hand tilted right , move car right
        USART_Tx(0x00);
        }
        else  if(xvoltage>175&&xvoltage <=200){// hand tilted Left , move car left
        USART_Tx(0x01);
        }
        else  if(xvoltage>=149&&xvoltage<=175){// hand  not tilted , car stationary
        USART_Tx(0x02);
        }
          if(yvoltage>=120&&yvoltage <140){// hand tilted full downward ,   fullspeed
        USART_Tx(0x03);
        }
        else if(yvoltage>=140&&yvoltage <150){// hand tilted half downward ,  halfspeed
        USART_Tx(0x04);

        }
        else if(yvoltage>=185&&yvoltage <200){// hand tilted full upward ,   fullspeed  backward
        USART_Tx(0x05);
        }
        else if(yvoltage>=168&&yvoltage <185){// hand tilted half upward,  halfspeed backward
        USART_Tx(0x06);
        }





}
}

 void USART_init(void){
     TRISC=0x80;// RC7 input,RC8 output;
     SPBRG=103;    // 1200BPS
     TXSTA=0X20;  // 8 -bit ,TX enable , Async, LOw speed;
     RCSTA=0X90; //SP enable, continous RX
     PORTC&=0xC0;
 }

 void USART_Tx(unsigned char mychar){
 while(!(TXSTA&0x02));
 TXREG=mychar;     // send when finish
 }


unsigned int ATD_read(int channel){
ADCON0=channel;
  ADCON0 = ADCON0 | 0x04;// GO
  while(ADCON0 & 0x04);
  return((ADRESH<<8) | ADRESL);
  }